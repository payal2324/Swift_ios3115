//
//  ViewController.swift
//  pickerpractise
//
//  Created by MacStudent on 2017-10-19.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource,UIPickerViewDelegate {

    
  
    

    @IBOutlet weak var countrypicker: UIPickerView!
    
    
    var country = ["India", "Canada", "Russia", "Australia","England", "Argentina","Germany","Poland","China","Japan" ]
    var job = ["ios","java","c++","mySql", "php"]
    @IBOutlet weak var lblcountry: UILabel!
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countrypicker.dataSource = self
        countrypicker.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
    if component == 0
    {
    return country.count
    
    }
    return job.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if component == 0{
        return country[row]
        }
        return job[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        pickerView.selectRow(row, inComponent: 0, animated: true)
        pickerView.selectRow(row, inComponent: 1, animated: true)
        
        lblcountry.text = "\(country[row]) - \(job[row])"
    }
    

}

