//
//  ViewController.swift
//  Demo
//
//  Created by MacStudent on 2017-10-16.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfUsername: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    @IBAction func btnLogin(_ sender: UIButton) {
        
        
        
       
        
        if (tfUsername.text == "admin" && tfPassword.text == "admin") {
            
            
            
            let storyBoard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let empVC = storyBoard.instantiateViewController(withIdentifier: "EmployeeVC") as! EmployeeVC
            self.present(empVC, animated: true, completion: nil)
            
            
//            let alert = UIAlertController(title: title,
//                                          message: "Welcome",
//                                          preferredStyle: UIAlertControllerStyle.alert)
//
//            let cancelAction = UIAlertAction(title: "OK",
//                                             style: .cancel, handler: nil)
//
//            alert.addAction(cancelAction)
//            self.present(alert, animated: true, completion: nil)
            
          
            
        }
        
        
    }
   
  

}

