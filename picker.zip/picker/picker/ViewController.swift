//
//  ViewController.swift
//  picker
//
//  Created by MacStudent on 2017-10-19.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
   
    

    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var mypicker: UIPickerView!
    
    var country = ["India", "Canada", "Russia", "Australia","England", "Argentina","Germany","Poland","China","Japan" ]
   
    
    
    
    
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        mypicker.dataSource = self
        mypicker.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return country.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return country[row]    // it will enter the country names in the picker
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        lbl1.text = country[row]   // this will show the selected value in the label
        print(country[mypicker.selectedRow(inComponent: 0)])
    }
}

