//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0718456
//  Student Name : Payal Khosla

import Foundation
class Student{

    var studentID: String!
    var studentName: String!
    var studentEmail: String!
    var studentDOB = Date()
     static var dict = [String:Student]()
    //   var marks  = ["English" : 0, "Maths" : 0 , "Computer": 0, "Science": 0, "Lab":0]
    
    init()
    {
        self.studentID = "-1"
        self.studentName = " "
        self.studentEmail = " "
        self.studentDOB = Date()
        // self.marks  = ["English" : 0, "Maths" : 0 , "Computer": 0, "Science": 0, "Lab":0]
    }
    
    init(_ studentID: String, _ studentName:String, _ studentEmail:String )
    {
        self.studentID = studentID
        self.studentName = studentName
        self.studentEmail = studentEmail
    
        //    self.studentDOB = studentDOB as String
        
    }
    
    func studentSave( _ studentID: String, _ studentName:String, _ studentEmail:String) -> Student
    {   var obj = Student()
        obj.studentID = studentID
        obj.studentName = studentName
        obj.studentEmail = studentEmail
        return obj
    }
    
    
}
