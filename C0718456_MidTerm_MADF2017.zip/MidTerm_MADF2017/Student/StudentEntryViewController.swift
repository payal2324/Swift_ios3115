//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0718456
//  Student Name : Payal Khosla

import UIKit

class StudentEntryViewController: UIViewController {

   var ud = UserDefaults.standard
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl4: UILabel!

    @IBOutlet weak var tfStudentID: UITextField!
    @IBOutlet weak var tfStudentName: UITextField!
    @IBOutlet weak var tfEmailID: UITextField!
    @IBOutlet weak var tfDOB: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    
   
    
    @IBOutlet weak var marks1: UITextField!
    
    @IBOutlet weak var marks2: UITextField!
    
    @IBOutlet weak var marks3: UITextField!
    
    
    @IBOutlet weak var marks4: UITextField!
    
    
    @IBOutlet weak var marks5: UITextField!
    
    @IBOutlet weak var lblTotal: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func actionSave(_ sender: UIButton) {
//        var stu = Student()
//        stu.studentID = (tfStudentID.text) as! String
//        stu.studentName = (tfStudentName.text) as! String
//        stu.studentEmail = (tfEmailID.text) as! String
//    stu.studentSave(stu.studentID, stu.studentName, stu.studentEmail)
// let m1 = (marks1.text).toInt()
//        let m2 = Int(marks2.text!).toInt()
//let m3 = Int(marks3.text).toInt()
//
//        let m4 = Int(marks4.text!).toInt()
//        let m5 = Int(marks5.text!).toInt()
//
        
   //    lblTotal.text =
        
        let alert = UIAlertController.init(title: "Record saved", message: "", preferredStyle: .alert)
        let action = UIAlertAction.init(title: "", style: .default, handler: {_ in self.segue()})
        alert.addAction(action)
       self.present(alert, animated: true, completion: nil)
    }
    
    func segue()
    {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StudentResultViewController") as! StudentResultViewController;        self.present(vc, animated: true, completion: nil)
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
