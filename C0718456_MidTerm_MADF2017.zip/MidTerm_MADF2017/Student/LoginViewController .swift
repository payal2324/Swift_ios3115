//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0718456
//  Student Name : Payal Khosla

import UIKit

class LoginViewController : UIViewController {
    var myUserDefault = UserDefaults.self
    @IBOutlet weak var lbl1: UILabel!
    
    @IBOutlet weak var lbl2: UILabel!
    
    @IBOutlet weak var tfUserid: UITextField!
    
    @IBOutlet weak var tfpassword: UITextField!
    
    
    @IBOutlet weak var btnLogin: UIButton!
    
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
      let  myUserDefault = UserDefaults.standard
        if let username = myUserDefault.value(forKey: "username")
        {
            tfUserid.text = username as? String
        }
        if let password = myUserDefault.value(forKey: "password")
        {
            tfpassword.text = password as? String
        }
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func segue()
    {
        let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "StudentEntryViewController") as! StudentEntryViewController
        self.present(vc, animated: true, completion: nil)
    }
    
    
    
    @IBAction func loginClick(_ sender: UIButton) {
        print("hello")
        if( (tfUserid.text == "C0718456") && (tfpassword.text == "Payal") )
        {
            let alert = UIAlertController.init(title: "Welcome", message: "Login Successful", preferredStyle:  .alert)
            let actionOk = UIAlertAction.init(title: "OK", style: .default, handler: {_ in self.segue()})
            alert.addAction(actionOk)
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController.init(title: "Welcome", message: "Login Failed", preferredStyle: .alert)
            let actionError = UIAlertAction.init(title: "Ooops", style: .destructive, handler: nil)
            alert.addAction(actionError)
            self.present(alert, animated: true, completion: nil)
        }
    }

}

